import os
import sys
import hashlib
import time
import sqlite3
from flask import Flask, request, jsonify
from flask_cors import CORS
import multiprocessing

# Connect to the database or create if not exists
conn = sqlite3.connect('log_database.db')
cursor = conn.cursor()

# Create the log table if it doesn't exist
cursor.execute('''
    CREATE TABLE IF NOT EXISTS logs (
        id INTEGER PRIMARY KEY,
        userId INTEGER,
        timestamp TEXT,
        message TEXT,
        username TEXT
    )
''')
conn.commit()


# Flask API functions
app = Flask(__name__)
CORS(app)


def log_data_for_user(userId):
    conn = sqlite3.connect('log_database.db')
    cursor = conn.cursor()
    cursor.execute(
        'SELECT timestamp, message,username FROM logs WHERE userId = ?', (userId,))
    data = cursor.fetchall()
    conn.close()
    log_entries = [{'timestamp': entry[0], 'message': entry[1], 'username': entry[2]}
                   for entry in data]
    return log_entries


@app.route('/get_logs', methods=['GET'])
def get_logs():
    userId = request.args.get('userId')
    if userId is None:
        return jsonify({'error': 'Missing userId parameter'}), 400

    log_entries = log_data_for_user(userId)
    return jsonify(log_entries)


def run_flask_app():
    app.run(host='0.0.0.0', port=8080)  # Adjust host and port as needed


# FIM functions
def write_to_db_log(userId, message):
    current_time = time.strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute('INSERT INTO logs (userId, timestamp, message, username) VALUES (?, ?, ?, ?)',
                   (userId, current_time, message, os.getlogin()))
    conn.commit()


def calculate_file_hash(filepath):
    with open(filepath, 'rb') as f:
        file_contents = f.read()
        hash_object = hashlib.sha512(file_contents)
        return hash_object.hexdigest()


def erase_baseline_if_already_exists():
    if os.path.exists('./baseline.txt'):
        os.remove('./baseline.txt')


def write_to_log(message):
    with open('userId.txt', 'r') as f:
        userId = f.read()
    write_to_db_log(userId, message)
    with open('./logs.txt', 'a') as log_file:
        current_time = time.strftime("%Y-%m-%d %H:%M:%S")
        log_file.write(f"{current_time}: {message}\n")


def clear_log_file():
    if os.path.exists('./logs.txt'):
        open('./logs.txt', 'w').close()


if __name__ == '__main__':
    flask_process = multiprocessing.Process(target=run_flask_app)
    flask_process.start()
    time.sleep(1)
    print("")
    print("What would you like to do?")
    print("")
    print("    A) Collect new Baseline?")
    print("    B) Begin monitoring files with saved Baseline?")
    print("")
    response = input("Please enter 'A' or 'B': ").upper()
    print("")

    with open('folder_path.txt', 'r') as folder_path_file:
        folder_path = folder_path_file.read().strip()

    if response == "A":
        erase_baseline_if_already_exists()

        files = [f for f in os.listdir(folder_path) if os.path.isfile(
            os.path.join(folder_path, f))]

        with open('./baseline.txt', 'a') as baseline_file:
            for f in files:
                file_path = os.path.join(folder_path, f)
                file_hash = calculate_file_hash(file_path)
                baseline_file.write(f"{file_path}|{file_hash}\n")
            flask_process.terminate()
            exit(1)

    elif response == "B":
        file_hash_dictionary = {}

        with open('./baseline.txt', 'r') as baseline_file:
            for line in baseline_file:
                file_path, file_hash = line.strip().split('|')
                file_hash_dictionary[file_path] = file_hash

        clear_log_file()  # Clear existing log entries at the start

        change_detected = {}  # Dictionary to track detected changes

        previous_files = []

        while True:
            time.sleep(1)

            files = [f for f in os.listdir(folder_path) if os.path.isfile(
                os.path.join(folder_path, f))]

            # Check for renamed files
            for f in previous_files:
                if f not in files:
                    message = f"{f} has been deleted by {os.getlogin()}!"
                    print(message)
                    write_to_log(message)

            for f in files:
                file_path = os.path.join(folder_path, f)
                hash_value = calculate_file_hash(file_path)

                if file_path not in file_hash_dictionary:
                    if change_detected.get(file_path) is None:
                        message = f"{file_path} has been created by {os.getlogin()}!"
                        print(message)
                        write_to_log(message)
                        change_detected[file_path] = hash_value

                elif file_hash_dictionary[file_path] == hash_value:
                    change_detected[file_path] = hash_value

                else:
                    if change_detected.get(file_path) is None or change_detected[file_path] != hash_value:
                        message = f"{file_path} has been changed by {os.getlogin()}!!!"
                        print(message)
                        write_to_log(message)
                        change_detected[file_path] = hash_value

            # Update previous_files with the current list
            previous_files = files[:]

            for key in list(file_hash_dictionary.keys()):
                if not os.path.exists(key):
                    if change_detected.get(key) is None:
                        message = f"{key} has been deleted by {os.getlogin()}!"
                        print(message)
                        write_to_log(message)
                        change_detected[key] = hash_value
                        del file_hash_dictionary[key]
